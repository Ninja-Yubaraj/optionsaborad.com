<?php

namespace App\Filament\Widgets;

use Filament\Widgets\Widget;

class ProgramWidget extends Widget
{
    protected static ?int $sort = 100;
    
    protected static string $view = 'filament.widgets.program-widget';
}
