<?php

namespace App\Filament\Admin\Resources\ForexRateResource\Pages;

use App\Filament\Admin\Resources\ForexRateResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateForexRate extends CreateRecord
{
    protected static string $resource = ForexRateResource::class;
}
