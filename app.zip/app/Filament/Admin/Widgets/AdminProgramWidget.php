<?php

namespace App\Filament\Admin\Widgets;

use Filament\Widgets\Widget;

class AdminProgramWidget extends Widget
{
    protected static string $view = 'filament.admin.widgets.admin-program-widget';

    protected static ?int $sort = 100;
}
