<?php

namespace App\Filament\User\Resources;

use Filament\Forms;
use Filament\Tables;
use App\Models\Program;
use Filament\Forms\Form;
use Filament\Tables\Table;
use Filament\Resources\Resource;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Enums\FiltersLayout;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use App\Filament\User\Resources\ProgramResource\Pages;
use App\Filament\User\Resources\ProgramResource\RelationManagers;

class ProgramResource extends Resource
{
    protected static ?string $model = Program::class;

    protected static ?string $navigationIcon = 'heroicon-o-magnifying-glass';

    protected static ?string $navigationLabel = 'Programs Search';

    protected static ?string $modelLabel = 'Programs Search';

    protected static bool $shouldRegisterNavigation = false;

    public static ?bool $filtersActive = false;

    public static function getEloquentQuery(): Builder
    {
        if (!request()->filled('tableFilters')) {
            return parent::getEloquentQuery()->where('id', null);
        
        } else {
            return parent::getEloquentQuery();

        }
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                //
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([

                Tables\Columns\TextColumn::make('institute.name')
                    ->searchable(),

                Tables\Columns\TextColumn::make('campus.name')
                    ->searchable(),

                Tables\Columns\TextColumn::make('program_name')
                    ->searchable()
                    ->label('Program Name'),

                Tables\Columns\TextColumn::make('duration.label')
                    ->sortable()
                    ->label('Duration'),

                Tables\Columns\TextColumn::make('co_op')
                    ->sortable()
                    ->label('Co Op'),
            ])
            ->filters([
                Tables\Filters\Filter::make('backlogs_and_study_gap')
                    ->form([
                        Forms\Components\Group::make()
                            ->schema([
                                Forms\Components\TextInput::make('backlogs')
                                    ->numeric()
                                    ->placeholder('e.g. 5, 12'),

                                Forms\Components\TextInput::make('study_gap')
                                    ->suffix('Months')
                                    ->label('Study Gap')
                                    ->placeholder('e.g. 1, 3')
                                    ->numeric(),
                            ])
                            ->columns(2)
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when(
                                $data['backlogs'] ?? null,
                                
                                function (Builder $query, $backlogs): Builder {
                                    return $query->whereRaw("CAST(backlogs AS UNSIGNED) >= ?", [(int) $backlogs]);
                                }
                            )
                            ->when(
                                $data['study_gap'] ?? null,
                                function (Builder $query, $study_gap): Builder {
                                    return $query->whereRaw("CAST(study_gap AS UNSIGNED) <= ?", [(int) $study_gap]);
                                }
                            );
                    }),

                Tables\Filters\Filter::make('exam')
                    ->form([
                        Forms\Components\Group::make()
                            ->schema([
                                Forms\Components\Select::make('exam')
                                    ->options([
                                        "Duolingo" => "Duolingo",
                                        "GMAT" => "GMAT",
                                        "GRE" => "GRE",
                                        "IELTS" => "IELTS",
                                        "PTE" => "PTE",
                                        "SAT" => "SAT",
                                        "TOEFL" => "TOEFL",
                                        "Others" => "Others",
                                    ])
                                    ->native(false),

                                Forms\Components\TextInput::make('listening')
                                    ->maxValue(9)
                                    ->numeric(),

                                Forms\Components\TextInput::make('speaking')
                                    ->maxValue(9)
                                    ->numeric(),

                                Forms\Components\TextInput::make('reading')
                                    ->maxValue(9)
                                    ->numeric(),

                                Forms\Components\TextInput::make('writing')
                                    ->maxValue(9)
                                    ->numeric(),
                            ])
                            ->columns(5)
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when(
                                $data['exam'] ?? null,
                                
                                function (Builder $query, $exam): Builder {
                                    return $query->whereJsonContains('exam', ['exam' => $exam]);
                                }
                            )
                            ->when(
                                $data['listening'] ?? null,
                                
                                function (Builder $query, $listening): Builder {

                                    return $query->whereRaw("CAST(JSON_EXTRACT(exam, '$[0].listening') AS UNSIGNED) <= ?", [$listening])->orWhereRaw("CAST(JSON_EXTRACT(exam, '$[1].listening') AS UNSIGNED) <= ?", [$listening])->orWhereRaw("CAST(JSON_EXTRACT(exam, '$[2].listening') AS UNSIGNED) <= ?", [$listening]);
                                }
                            )
                            ->when(
                                $data['reading'] ?? null,
                                
                                function (Builder $query, $reading): Builder {

                                    return $query->whereRaw("CAST(JSON_EXTRACT(exam, '$[0].reading') AS UNSIGNED) <= ?", [$reading])->orWhereRaw("CAST(JSON_EXTRACT(exam, '$[1].reading') AS UNSIGNED) <= ?", [$reading])->orWhereRaw("CAST(JSON_EXTRACT(exam, '$[2].reading') AS UNSIGNED) <= ?", [$reading]);
                                }
                            )
                            ->when(
                                $data['speaking'] ?? null,
                                
                                function (Builder $query, $speaking): Builder {

                                    return $query->whereRaw("CAST(JSON_EXTRACT(exam, '$[0].speaking') AS UNSIGNED) <= ?", [$speaking])->orWhereRaw("CAST(JSON_EXTRACT(exam, '$[1].speaking') AS UNSIGNED) <= ?", [$speaking])->orWhereRaw("CAST(JSON_EXTRACT(exam, '$[2].speaking') AS UNSIGNED) <= ?", [$speaking]);
                                }
                            )
                            ->when(
                                $data['writing'] ?? null,
                                
                                function (Builder $query, $writing): Builder {

                                    return $query->whereRaw("CAST(JSON_EXTRACT(exam, '$[0].writing') AS UNSIGNED) <= ?", [$writing])->orWhereRaw("CAST(JSON_EXTRACT(exam, '$[1].writing') AS UNSIGNED) <= ?", [$writing])->orWhereRaw("CAST(JSON_EXTRACT(exam, '$[2].writing') AS UNSIGNED) <= ?", [$writing]);
                                }
                            );
                    }),

                    Tables\Filters\Filter::make('percentage')
                        ->form([
                    
                            Forms\Components\TextInput::make('percentage')
                                ->suffix('%')
                                ->numeric()
                                ->placeholder('e.g. 10, 30, 60'),
                                
                        ])
                        ->query(function (Builder $query, array $data): Builder {
                            return $query
                                ->when(
                                    $data['percentage'] ?? null,
                                    function (Builder $query, $percentage): Builder {
                                        return $query->whereRaw("CONVERT(SUBSTRING_INDEX(percentage_bucket, '-', 1), SIGNED) < ?", [$percentage]);
                                    }
                                );
                        }),
                    

            ], layout: FiltersLayout::Hidden)
            ->filtersFormColumns(1)

            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPrograms::route('/'),
            // 'create' => Pages\CreateProgram::route('/create'),
            // 'edit' => Pages\EditProgram::route('/{record}/edit'),
        ];
    }

    public static function canCreate(): bool 
    {
        return false;
    }

    public static function canEdit($record): bool 
    {
        return false;
    }
}
