<?php

namespace App\Filament\User\Pages;

use App\Models\SearchLog;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Pages\Page;
use Filament\Actions\Action;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Concerns\InteractsWithForms;

class ProgramSearch extends Page implements HasForms
{
    use InteractsWithForms;

    public ?array $data = []; 

    protected static string $view = 'filament.user.pages.program-search';

    protected static ?string $navigationIcon = 'heroicon-o-magnifying-glass';

    protected static ?string $navigationLabel = 'Programs Search';

    protected static ?string $modelLabel = 'Programs Search';

    protected static ?int $sort = 100;

    public function mount(): void 
    {
        $this->form->fill();
    }
 
    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make()
                    ->schema([
                        Forms\Components\Group::make()
                            ->schema([
                                Forms\Components\TextInput::make('backlogs')
                                    ->required()
                                    ->numeric()
                                    ->placeholder('e.g. 5, 12'),

                                Forms\Components\TextInput::make('study_gap')
                                    ->suffix('Months')
                                    ->label('Study Gap')
                                    ->placeholder('e.g. 1, 3')
                                    ->numeric(),
                            ])
                            ->columns(2),

                        Forms\Components\Group::make()
                            ->schema([
                                Forms\Components\Select::make('exam')
                                    ->required()
                                    ->options([
                                        "Duolingo" => "Duolingo",
                                        "GMAT" => "GMAT",
                                        "GRE" => "GRE",
                                        "IELTS" => "IELTS",
                                        "PTE" => "PTE",
                                        "SAT" => "SAT",
                                        "TOEFL" => "TOEFL",
                                        "Others" => "Others",
                                    ])
                                    ->native(false),

                                Forms\Components\TextInput::make('listening')
                                    ->required()
                                    ->maxValue(9)
                                    ->numeric(),

                                Forms\Components\TextInput::make('speaking')
                                    ->required()
                                    ->maxValue(9)
                                    ->numeric(),

                                Forms\Components\TextInput::make('reading')
                                    ->required()
                                    ->maxValue(9)
                                    ->numeric(),

                                Forms\Components\TextInput::make('writing')
                                    ->required()
                                    ->maxValue(9)
                                    ->numeric(),
                            ])
                            ->columns(5),

                            Forms\Components\TextInput::make('percentage')
                                ->required()
                                ->suffix('%')
                                ->numeric()
                                ->placeholder('e.g. 10, 30, 60'),
                    ])
            ])
            ->statePath('data');
    } 

    protected function getFormActions(): array
    {
        return [
            Action::make('search')
                ->label('Search')
                ->submit('search'),
        ];
    }

    public function search() 
    {
        $data = $this->form->getState();

        $url = "/user/programs?" .
            "tableFilters[backlogs_and_study_gap][backlogs]={$data['backlogs']}&" .
            "tableFilters[backlogs_and_study_gap][study_gap]={$data['study_gap']}&" .
            "tableFilters[exam][exam]={$data['exam']}&" .
            "tableFilters[exam][listening]={$data['listening']}&" .
            "tableFilters[exam][speaking]={$data['speaking']}&" .
            "tableFilters[exam][reading]={$data['reading']}&" .
            "tableFilters[exam][writing]={$data['writing']}&" .
            "tableFilters[percentage][percentage]={$data['percentage']}";

        $searchLogData = $data;

        $searchLogData['user_id'] = auth()->id();

        SearchLog::create($searchLogData);
        
        return redirect($url);
    }
}
