<x-filament-widgets::widget>
    <div class="w-[25%]">
        {{ $this->form }}
    </div>
</x-filament-widgets::widget>
