<div class="flex items-center">
    <img 
        style="width: auto; height: 60px;" 
        src="{{ asset('images/horizontal.png') }}" 
        alt="{{ env("APP_NAME") }}"
    />
</div>
