<div class="flex items-center">
    <img 
        style="width: auto; height: 60px;" 
        src="<?php echo e(asset('images/horizontal.png')); ?>" 
        alt="<?php echo e(env("APP_NAME")); ?>"
    />
</div>
<?php /**PATH /home/client2/source.public_html/resources/views/filament/data/logo.blade.php ENDPATH**/ ?>