<?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
<?php /**PATH /home/client2/source.public_html/resources/views/styles.blade.php ENDPATH**/ ?>