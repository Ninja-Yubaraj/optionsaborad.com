<?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => ['class' => 'hidden md:block floating-section']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'hidden md:block floating-section']); ?>
    <style>
        @media (min-width: 768px) {
            /* Styling for medium-sized screens (laptops) */
            .fi-main {
                padding-right: 220px;
            }

            .floating-section {
                min-width: 200px;
                max-width: 250px;
                position: fixed !important;
                right: 0;
                margin-right: 20px;
                margin-top: 80px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            }

            
            .floating-section h3 {
                font-size: 18px;
                font-weight: bold;
                color: #333;
                margin-bottom: 10px;
                text-transform: uppercase;
                border-bottom: 2px solid #ccc;
                padding-bottom: 5px;
                text-align: center;
            }

            .floating-section .p-6 {
                padding: 0.5rem;
            }

            .rate {
                color: #009900;
                font-weight: bold;
            }

        }
    </style>

    <?php
    $forexRates = App\Models\ForexRate::all();
    ?>
    <div>
        <h3>Forex Rates</h3>
    </div>
    <div>
        <ul>
            <?php $__currentLoopData = $forexRates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forexRate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li style="margin-bottom: 5px; margin-left: 7px"><?php echo e($forexRate->from); ?>-<?php echo e($forexRate->to); ?> <span class="rate"><?php echo e(number_format($forexRate->rate, 2)); ?></span></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => ['class' => 'hidden md:block floating-section','style' => 'bottom: 0 !important; padding: 1px; margin-bottom: 20px !important; max-width: 200px !important;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'hidden md:block floating-section','style' => 'bottom: 0 !important; padding: 1px; margin-bottom: 20px !important; max-width: 200px !important;']); ?>
    <ul style="margin: 0; padding: 0;">
        <li style="margin: 0; padding: 0; margin-bottom: 5px; margin-left: 7px; font-size: 15px;">
            For technical <br/> queries contact
            <a href="tel:+918780082392" style="display: inline-block; white-space: nowrap;">
                <span style="color: #04cae0; font-weight: bold;">+918780082392</span>
            </a>
        </li>
        <li style="margin: 0; padding: 0; margin-bottom: 5px; margin-left: 7px; font-size: 14px;">
            For Program related queries contact
            <a href="tel:+918780082392" style="display: inline-block; white-space: nowrap;">
                <span style="color: #04cae0; font-weight: bold;">+917600958750</span>
            </a>
        </li>
    </ul>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>


<?php /**PATH /home/client2/source.public_html/resources/views/boxes.blade.php ENDPATH**/ ?>